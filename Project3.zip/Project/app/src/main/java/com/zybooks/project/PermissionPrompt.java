package com.zybooks.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class PermissionPrompt extends AppCompatActivity {

    private Button _approveButton;
    private Button _denyButton;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.permission_prompt);
        _approveButton = findViewById(R.id.buttonApprove);
        _denyButton = findViewById(R.id.buttonDeny);
        _approveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getBaseContext(), DataLayoutActivity.class));
            }
        });

        _denyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getBaseContext(), DataLayoutActivity.class));
            }
        });

    }
}
