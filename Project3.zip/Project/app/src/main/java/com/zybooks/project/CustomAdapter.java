package com.zybooks.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter  extends ArrayAdapter{

    ArrayList<Item> _itemList = new ArrayList<>();
    CompanyDatabaseHelper _db;
    View dataLayoutView;
    public CustomAdapter(Context applicationContext, int textViewResourceId, int textViewId, ArrayList items, CompanyDatabaseHelper db)
    {
        super(applicationContext, textViewResourceId, textViewId, items);
        _itemList = items;
        _db = db;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        View gridItemView = convertView;
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        gridItemView = inflater.inflate(R.layout.grid_view_items, null);
        dataLayoutView = inflater.inflate(R.layout.data_layout, null);
        TextView itemAmount = (TextView) gridItemView.findViewById(R.id.itemAmount);
        TextView itemName = (TextView) gridItemView.findViewById(R.id.itemName);
        TextView editAmount = (TextView) dataLayoutView.findViewById(R.id.editAmount);
        Button editButton = (Button) gridItemView.findViewById(R.id.buttonEditItem);
        Button deleteButton = (Button) gridItemView.findViewById(R.id.buttonDeleteItem);
        itemName.setText(_itemList.get(position).getItemName());
        itemAmount.setText( Integer.toString(_itemList.get(position).getAmount()));
        editButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                _db.updateItem(_db.getItemByName(itemName.getText().toString()), Integer.valueOf(editAmount.getText().toString()));
                itemAmount.setText(editAmount.getText());
                ((DataLayoutActivity)getContext()).refresh();
            }

        });
        deleteButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                _db.deleteItem(_db.getItemByName(itemName.getText().toString()));
                ((DataLayoutActivity)getContext()).refresh();
            }

        });
        return gridItemView;
    }
}
