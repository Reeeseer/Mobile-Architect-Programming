package com.zybooks.project;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity{

    private Button _buttonLogIn;
    private Button _buttonCreateAccount;
    private TextView _usernameText;
    private TextView _passwordText;
    private TextView _greetingText;
    private SQLiteDatabase _companyDB;
    private static String DB_PATH = "/data/data/com.zybooks.project/databases/";

    private static String DB_NAME = "company.db";
    private NotificationManager _noteManger;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        _buttonLogIn = findViewById(R.id.buttonLogIn);
        _buttonCreateAccount = findViewById(R.id.buttonCreateLogin);
        _usernameText = findViewById(R.id.usernameText);
        _passwordText = findViewById(R.id.passwordText);
        _greetingText = findViewById(R.id.greetingText);
        File file = new File(DB_PATH);
        file.mkdirs();

       _companyDB = SQLiteDatabase.openDatabase(DB_PATH + DB_NAME,
                null,
                SQLiteDatabase.CREATE_IF_NECESSARY);

       CompanyDatabaseHelper db = new CompanyDatabaseHelper(getBaseContext());
       _buttonLogIn.setOnClickListener(new View.OnClickListener(){
           public void onClick(View v)
           {
               boolean success = db.getUser( _usernameText.getText().toString(), _passwordText.getText().toString());
               if (success)
               {
                    startActivity(new Intent(getBaseContext(), PermissionPrompt.class));
               }
               else
               {
                    _greetingText.setText("Cannot find user, please create an account");
               }
           }
       });

       _buttonCreateAccount.setOnClickListener(new View.OnClickListener(){
           public void onClick(View v)
           {
               boolean success = db.addUser(_usernameText.getText().toString(), _passwordText.getText().toString()) != -1;
               if (success)
               {
                   _greetingText.setText("Account created");
               }
               else {
                   _greetingText.setText("Account Creation failed");
               }
           }
       });
    }
}
