package com.zybooks.project;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.Objects;

public class CompanyDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "company.db";
    private static final int VERSION = 1;

    public CompanyDatabaseHelper(Context context)
    {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable
    {
        private static final String TABLE = "Inventory";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_AMOUNT = "amount";
    }

    private static final class UserTable
    {
        private static final String TABLE = "Users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table if not exists " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_NAME + " text, " +
                InventoryTable.COL_AMOUNT + " int) ");

        db.execSQL("create table if not exists " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public ArrayList<Item> GetItems()
    {
        ArrayList<Item> items = new ArrayList<>();
        SQLiteDatabase db =  getReadableDatabase();
        String sql = "select * from " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst())
        {
            do {
                long itemId = cursor.getLong(0);
                String itemName = cursor.getString(1);
                int itemAmount = cursor.getInt(2);

                items.add(new Item(Objects.toString(itemId, null), itemName, itemAmount));

                Log.d(TAG, "Item = " + itemId + ", " + itemName + ", " + itemAmount);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return  items;
    }


    public long addItem(String name, int amount)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_NAME, name);
        values.put(InventoryTable.COL_AMOUNT, amount);

        long itemId = db.insert(InventoryTable.TABLE, null, values);
        return  itemId;
    }

    public long getItemByName(String name)
    {
        SQLiteDatabase db =  getReadableDatabase();
        long id = -1;
        String sql = "select * from " + InventoryTable.TABLE + " where name = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {name});
        if (cursor.moveToFirst())
        {
            do {
                long itemId = cursor.getLong(0);
                id = itemId;
                String itemName = cursor.getString(1);
                int itemAmount = cursor.getInt(2);
                Log.d(TAG, "Item = " + itemId + ", " + itemName + ", " + itemAmount);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return id;
    }

    public boolean updateItem(long id, int amount) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_AMOUNT, amount);

        int rowsUpdated = db.update(InventoryTable.TABLE, values, "_id = ?",
                new String[] { Float.toString(id) });
        return rowsUpdated > 0;
    }

    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?",
                new String[] { Long.toString(id) });
        return rowsDeleted > 0;
    }

    public long addUser(String userName, String password)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, userName);
        values.put(UserTable.COL_PASSWORD, password);

        long userId = db.insert(UserTable.TABLE, null, values);
        return  userId;
    }

    public Boolean getUser(String userName, String password)
    {
        Boolean gotUser = false;
        SQLiteDatabase db =  getReadableDatabase();

        String sql = "select * from " + UserTable.TABLE + " where username = ? and password = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {userName, password});
        if (cursor.moveToFirst())
        {
            do {
                gotUser = true;
                long userId = cursor.getLong(0);
                String userUserName = cursor.getString(1);
                String userAmount = cursor.getString(2);
                Log.d(TAG, "Item = " + userId + ", " + userUserName + ", " + userAmount);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return gotUser;
    }

    public boolean updateUser(long id, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_PASSWORD, password);

        int rowsUpdated = db.update(UserTable.TABLE, values, "_id = ?",
                new String[] { Float.toString(id) });
        return rowsUpdated > 0;
    }

    public boolean deleteUser(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(UserTable.TABLE, UserTable.COL_ID + " = ?",
                new String[] { Long.toString(id) });
        return rowsDeleted > 0;
    }
}
