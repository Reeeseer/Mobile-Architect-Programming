package com.zybooks.project;

import android.database.sqlite.SQLiteDatabase;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DataLayoutActivity extends AppCompatActivity {

    private TextView _editItem;
    private TextView _editAmount;
    private Button _buttonAddItem;
    private GridView _dataGrid;

    private SQLiteDatabase _companyDB;
    private static String DB_PATH = "/data/data/com.zybooks.project/databases/";

    private static String DB_NAME = "company.db";
    private ArrayList<Item> _list;
    private CustomAdapter _adapter;
    CompanyDatabaseHelper _db;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_layout);
        _editItem = findViewById(R.id.editItem);
        _editAmount = findViewById(R.id.editAmount);
        _buttonAddItem = findViewById(R.id.buttonAddItem);
        _dataGrid = findViewById(R.id.dataGrid);
        _companyDB = SQLiteDatabase.openDatabase(DB_PATH + DB_NAME,
                null,
                SQLiteDatabase.CREATE_IF_NECESSARY);

        _db = new CompanyDatabaseHelper(getBaseContext());

        _buttonAddItem.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                    _db.addItem( _editItem.getText().toString(), Integer.valueOf(_editAmount.getText().toString()));
                    refresh();
            }
        });
        _list = _db.GetItems();

        _adapter = new CustomAdapter(this, R.layout.grid_view_items, R.id.itemName, _list, _db);
        _dataGrid.setAdapter(_adapter);
    }

    //Refreshes the activity for updated listings
    public void refresh()
    {
        finish();
        overridePendingTransition(0, 0);
        startActivity(getIntent());
        overridePendingTransition(0, 0);
    }
}
