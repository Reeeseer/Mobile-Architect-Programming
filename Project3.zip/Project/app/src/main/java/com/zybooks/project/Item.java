package com.zybooks.project;

public class Item {
    String _id;
    String _name;
    int _amount;

    public Item(String id, String name, int amount)
    {
        _id = id;
        _name = name;
        _amount = amount;
    }

    public String getId()
    {
        return _id;
    }
    public String getItemName()
    {
        return _name;
    }
    public int getAmount()
    {
        return _amount;
    }
    public void setAmount(int newAmount)
    {
        _amount = newAmount;
    }
}
